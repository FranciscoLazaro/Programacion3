package com.example.demosistemaVentas.Otros;

public enum TipoEnvio {
    Delivery, Retira
}
