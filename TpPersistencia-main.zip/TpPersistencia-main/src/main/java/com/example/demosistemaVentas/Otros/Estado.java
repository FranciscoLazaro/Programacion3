package com.example.demosistemaVentas.Otros;

public enum Estado {
    Iniciado, Preparado, Entregado
}
