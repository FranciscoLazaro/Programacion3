package com.example.demosistemaVentas.Otros;

public enum FormaPago {
    Efectivo, Tarjeta, Transferencia
}
