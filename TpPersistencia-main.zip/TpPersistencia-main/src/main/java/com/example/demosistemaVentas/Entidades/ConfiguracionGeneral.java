package com.example.demosistemaVentas.Entidades;

public class ConfiguracionGeneral extends BaseEntidad{
    private int cantidadCocinero;
    private String emailEmpresa;
    private String tokenenMercadoPago;
}
