package com.example.demosistemaVentas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemosistemaVentasApplicationTests {

	@Test
	void contextLoads() {
	}

}
